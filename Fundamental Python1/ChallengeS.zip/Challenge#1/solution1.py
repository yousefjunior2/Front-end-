print("challenge1:")


message = "This is going to be tricky ;)"
 
Message = "very tricky"
print(message)

result= 3**2
print("3**2=",result)

result = 3 - 5 
print("Challenge complete!") 