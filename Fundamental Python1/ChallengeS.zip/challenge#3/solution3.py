def calculate (number1,number2,number3):
    return((number1+number2)*number3)

print(calculate(2,4,5))
print(calculate(2,6,5))
print(calculate(2,4,3))
