
fruits=[
    'apples',
    'bananas',
    'grapes',
    "mangos",
    'nectarines',
    'pears' 
]

print("My favorite fruits" )

# for fruit in fruits:
#         print(fruit.capitalize()) 
# print("Loop is Done!")  
print('___________________________')
# for fruit in fruits:
#        if fruit != "nectarines":
#         print(fruit.capitalize()) 
# print("Loop is Done!")  
print("__________________________________")
# print("My favorite fruits" )

# a=0
# while fruits[a] != "nectarines":
#        print(fruits[a])
#        a += 1
# print("Loop is Done!")  
print('_____________________________')
# for fruit in fruits :
#     if fruit == "nectarines":
#      continue
#     print(fruit.capitalize())

# print("Loop is Done!")  
print("______________________________")

for fruit in fruits:
    while fruit <fruits[4]:
        print(fruit)
        break
    print(fruit)




