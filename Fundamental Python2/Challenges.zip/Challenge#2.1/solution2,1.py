

star1 = "sol"
star2 = "Alpha Centauri"
star3 = "Barnard"
star4 = "wolf"
 
starslist=[
    "sol",
     "Alpha Centauri",
      "Barnard",
       "wolf"
]
print(starslist[3])
print("______________________________")

peaks={
    "African" : "Kilimanjaro",
    "Australian" : "Vinson",
    "Antarctic" : "Puncak",
    "Euras" : "Everest",
    "Nourth_American" : "Denali",
    "Pacific" : "Mauna kea",
    "south_American" : "Aconcagua"
}
print(peaks["Pacific"])
