def Sum(num1,num2):
    return( num1+num2)

def Multiply(num1,num2):
    return( num1*num2)

def Subtract(num1,num2):
    return( num1-num2)

def Division(num1,num2):
    return( num1/num2)

