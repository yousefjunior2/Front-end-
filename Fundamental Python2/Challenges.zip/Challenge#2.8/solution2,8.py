from Cat import Cat

SiameseCat = Cat("Hanafi","Siamese","apricot",6,"three steps/sec","Twenty steps/sec",)
SiameseCat.Walking()
SiameseCat.Running()

ShiraziCat = Cat("Semsima","Shirazi","White",3,"ten steps/sec","Fifty steps/sec",)
ShiraziCat.Walking()
ShiraziCat.Running()

SiameseCat = Cat("Habshiyeh","Antar","black",9,"one steps/sec","one hundred steps/sec",)
SiameseCat.Walking()
SiameseCat.Running()